from flask import Flask, render_template, request
import tensorflow as tf
import os
import numpy as np
from PIL import Image

app = Flask(__name__)

# Load the model
model = tf.keras.models.load_model('model.h5')  # Ensure the model is in .h5 format

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return "No image uploaded", 400
    file = request.files['image']
    image_path = os.path.join('uploads', file.filename)
    os.makedirs(os.path.dirname(image_path), exist_ok=True)
    file.save(image_path)
    
    preprocessed_img = preprocess_image(image_path)
    prediction = predict_image(preprocessed_img)
    
    prediction_text = "copied" if prediction == 1 else "original"
    os.remove(image_path)
    
    return render_template('result.html', image_path=image_path, prediction=prediction_text)

def preprocess_image(image_path):
  img=Image.open(image_path)
  img = img.convert('RGB')
  img=img.resize((64,64))
  img=np.expand_dims(img,axis=0)
  img=np.array(img)
  img=img/255
  return img

def predict_image(processed_img):
    prediction=np.argmax(model.predict(processed_img))
    return prediction

if __name__ == '__main__':
    app.run(debug=True)
